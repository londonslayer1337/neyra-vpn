# Neyra VPN Bot

A zero-cost-oriented Telegram bot architecture for Railway plus GitHub Pages. It collects public subscription sources, validates their URI structure, deduplicates entries, publishes the latest successful build through GitHub Pages, and generates AmneziaWG configs on demand.

## Runtime secrets

Set these in Railway:

- `BOT_TOKEN` — Telegram bot token.
- `ADMIN_USER_ID` — your numeric Telegram user ID. Only this ID gets the admin status button.

Optional:

- `NEYRA_BASE_URL` — GitHub Pages base URL.
- `LOG_LEVEL` — default `INFO`.

## GitHub Pages

Enable Pages using **GitHub Actions** as the source. The scheduled workflow rebuilds the subscription every four hours and deploys only the generated `docs/` site. It does not commit generated files back to the repository, so it cannot create a push-trigger loop.

## Important limitation

The collector validates configuration syntax and source availability. It does not claim that every published endpoint is reachable from every network. Public endpoints can disappear or be blocked; the design therefore keeps multiple sources and refuses to publish a build that falls below the minimum node count.
