from __future__ import annotations

import asyncio
import base64
import json
import os
from datetime import datetime, timezone
from pathlib import Path

from app.services.collector import SOURCES, collect_nodes

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs" / "sub"


def write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(content, encoding="utf-8")
    os.replace(tmp, path)


async def main() -> None:
    min_nodes = int(os.getenv("NEYRA_MIN_NODES", "5"))
    nodes, source_stats = await collect_nodes()
    if len(nodes) < min_nodes:
        raise SystemExit(f"Refusing weak build: {len(nodes)} nodes < {min_nodes}")

    plain = "\n".join(n.uri for n in nodes) + "\n"
    encoded = base64.b64encode(plain.encode()).decode() + "\n"
    schemes = {s: sum(n.scheme == s for n in nodes) for s in sorted({n.scheme for n in nodes})}
    stats = {
        "schema_version": 1,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "nodes": len(nodes),
        "sources_total": len(SOURCES),
        "sources_ok": sum(1 for s in source_stats.values() if s["ok"]),
        "sources_failed": sum(1 for s in source_stats.values() if not s["ok"]),
        "schemes": schemes,
        "source_stats": source_stats,
    }
    write(OUT / "base64.txt", encoded)
    write(OUT / "plain.txt", plain)
    write(OUT / "stats.json", json.dumps(stats, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"nodes": len(nodes), "sources_ok": stats["sources_ok"], "sources_failed": stats["sources_failed"]}))


if __name__ == "__main__":
    asyncio.run(main())
