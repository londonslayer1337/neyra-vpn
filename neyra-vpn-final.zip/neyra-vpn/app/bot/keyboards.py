from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


def main_keyboard(is_admin: bool) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text="⚡ AmneziaWG", callback_data="awg")],
        [InlineKeyboardButton(text="🌐 VLESS-подписка", callback_data="vless")],
        [InlineKeyboardButton(text="📱 Как подключить", callback_data="help")],
    ]
    if is_admin:
        rows.append([InlineKeyboardButton(text="👑 Статус Neyra", callback_data="admin_status")])
    return InlineKeyboardMarkup(inline_keyboard=rows)
