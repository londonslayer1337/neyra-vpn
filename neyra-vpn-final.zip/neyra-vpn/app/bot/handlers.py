from __future__ import annotations

import logging

from aiogram import F, Router, types
from aiogram.filters import CommandStart
from aiogram.types import BufferedInputFile

from app.bot.keyboards import main_keyboard
from app.config import Settings
from app.services.amneziawg import build_config, register
from app.services.subscription import SubscriptionService

log = logging.getLogger(__name__)
router = Router()


def is_admin(settings: Settings, user_id: int | None) -> bool:
    return bool(user_id and settings.admin_user_id and str(user_id) == settings.admin_user_id)


@router.message(CommandStart())
async def start(message: types.Message, settings: Settings) -> None:
    await message.answer(
        "👋 <b>Neyra</b>\n\nВыбери способ подключения:",
        parse_mode="HTML",
        reply_markup=main_keyboard(is_admin(settings, message.from_user.id if message.from_user else None)),
    )


@router.callback_query(F.data == "awg")
async def awg(callback: types.CallbackQuery, settings: Settings) -> None:
    await callback.answer("Готовлю AmneziaWG…")
    try:
        data = await register()
        document = BufferedInputFile(build_config(data).encode(), filename="AmneziaWG_Neyra.conf")
        await callback.message.answer_document(
            document=document,
            caption="⚡ <b>AmneziaWG</b>\n\nНовый конфиг готов. Импортируй файл в AmneziaWG.",
            parse_mode="HTML",
            reply_markup=main_keyboard(is_admin(settings, callback.from_user.id)),
        )
    except Exception:
        log.exception("AmneziaWG generation failed")
        await callback.message.answer(
            "❌ Не удалось получить новый AmneziaWG-конфиг. Попробуй ещё раз позже.",
            reply_markup=main_keyboard(is_admin(settings, callback.from_user.id)),
        )


@router.callback_query(F.data == "vless")
async def vless(callback: types.CallbackQuery, settings: Settings) -> None:
    await callback.answer()
    await callback.message.answer(
        "🌐 <b>Универсальная подписка Neyra</b>\n\n"
        f"<code>{settings.subscription_url}</code>\n\n"
        "Добавь URL в раздел Subscription/Подписки клиента и нажми Update.",
        parse_mode="HTML",
        reply_markup=main_keyboard(is_admin(settings, callback.from_user.id)),
    )


@router.callback_query(F.data == "help")
async def help_handler(callback: types.CallbackQuery, settings: Settings) -> None:
    await callback.answer()
    await callback.message.answer(
        "📖 <b>Как подключить</b>\n\n"
        "⚡ AmneziaWG — импортируй полученный .conf-файл.\n\n"
        "🌐 Happ / 2RayTun / v2rayNG / Hiddify — добавь ссылку Neyra как подписку и обнови её.\n\n"
        "Если соединение перестало работать, сначала обнови подписку.",
        parse_mode="HTML",
        reply_markup=main_keyboard(is_admin(settings, callback.from_user.id)),
    )


@router.callback_query(F.data == "admin_status")
async def admin_status(callback: types.CallbackQuery, settings: Settings) -> None:
    if not is_admin(settings, callback.from_user.id):
        await callback.answer("Нет доступа.", show_alert=True)
        return
    await callback.answer("Проверяю…")
    stats = await SubscriptionService(settings.subscription_url, settings.stats_url).stats()
    if not stats:
        text = "👑 <b>NEYRA STATUS</b>\n\n🟢 Bot: ONLINE\n🔴 Subscription: UNAVAILABLE\n\nНе удалось получить stats.json."
    else:
        text = (
            "👑 <b>NEYRA STATUS</b>\n\n"
            "🟢 Bot: ONLINE\n"
            "🟢 Subscription: HEALTHY\n"
            f"📦 Nodes: <b>{stats.get('nodes', 0)}</b>\n"
            f"🟢 Sources OK: {stats.get('sources_ok', 0)}\n"
            f"🔴 Sources failed: {stats.get('sources_failed', 0)}\n"
            f"🕐 Last build: <code>{stats.get('generated_at', 'unknown')}</code>"
        )
    await callback.message.answer(text, parse_mode="HTML", reply_markup=main_keyboard(True))
