from __future__ import annotations

import httpx


class SubscriptionService:
    def __init__(self, url: str, stats_url: str):
        self.url = url
        self.stats_url = stats_url

    async def stats(self) -> dict | None:
        try:
            async with httpx.AsyncClient(timeout=8, follow_redirects=True) as client:
                response = await client.get(self.stats_url)
                response.raise_for_status()
                return response.json()
        except Exception:
            return None
